'use strict';

$(function () {
  var foo1 = 8;
  var foo = 1,
      bar = 2,
      baz = 3;

  console.log(foo1);
  console.log(foo);
  console.log(bar);

  new Vue({
    el: '#site',
    data: function data() {
      return {
        poets: [{
          tit: '江上值水如海势聊短述',
          author: '杜甫',
          txt: '为人性僻耽佳句，语不惊人死不休！老去诗篇浑漫兴，春来花鸟莫生愁。新添水槛供垂钓，故着浮槎替入舟。焉得思如陶谢手，令渠述作与同游。',
          href: 'https://pop3.mrhanjinbao.com/2016/10/28/%E8%AF%97%E5%9C%A3-%E6%9D%9C%E7%94%AB/'
        }, {
          tit: '蝶恋花',
          author: '李清照',
          txt: '泪湿罗衣脂粉满，四叠阳关，唱到千千遍。人道山长水又断，萧萧微雨闻孤馆。惜别伤离方寸乱，忘了临行，酒盏深和浅。好把音书凭过雁，东莱不似蓬莱远。',
          href: 'https://pop3.mrhanjinbao.com/2016/10/06/%E5%8D%83%E5%8F%A4%E7%AC%AC%E4%B8%80%E6%89%8D%E5%A5%B3-%E6%9D%8E%E6%B8%85%E7%85%A7/'
        }, {
          tit: '侠客行',
          author: '李白',
          txt: '赵客缦胡缨，吴钩霜雪明。银鞍照白马，飒沓如流星。十步杀一人，千里不留行。事了拂衣去，深藏身与名。闲过信陵饮，脱剑膝前横。将炙啖朱亥，持觞劝侯嬴。三杯吐然诺，五岳倒为轻。眼花耳热后，意气素霓生。救赵挥金槌，邯郸先震惊。千秋二壮士，烜赫大梁城。纵死侠骨香，不惭世上英。谁能书阁下，白首太玄经。',
          href: 'https://pop3.mrhanjinbao.com/2016/10/08/%E9%85%92%E5%89%91%E4%BB%99-%E6%9D%8E%E7%99%BD/'
        }, {
          tit: '虞美人',
          author: '李煜',
          txt: '春花秋月何时了？往事知多少。小楼昨夜又东风，故国不堪回首月明中。雕栏玉砌应犹在，只是朱颜改。问君能有几多愁？恰似一江春水向东流。',
          href: 'https://pop3.mrhanjinbao.com/2016/10/16/%E8%AF%8D%E5%B8%9D-%E6%9D%8E%E7%85%9C/'
        }],
        cats: [{
          href: 'javascript:;',
          src: '<img src="./images/0.1.jpg">'
        }, {
          href: 'javascript:;',
          src: '<img src="./images/0.2.jpg">'
        }, {
          href: 'javascript:;',
          src: '<img src="./images/0.3.jpg">'
        }, {
          href: 'javascript:;',
          src: '<img src="./images/0.4.jpg">'
        }, {
          href: 'javascript:;',
          src: '<img src="./images/0.5.jpg">'
        }],
        news: [],
        test: 'nudfdfd'
      };
    },
    created: function created() {
      // 多读书
      this.read();
      // 天气
      weather();
    },
    mounted: function mounted() {
      // 导航
      nav();
      console.log(5);
    },
    methods: {
      read: function read() {
        var _this = this;
        $.ajax({
          url: 'https://cnodejs.org/api/v1/topics',
          type: 'get',
          crossDomain: true,
          success: function success(data) {
            _this.news = data.data.filter(function (v, i) {
              return i < 10;
            });
          },
          error: function error(e) {
            console.log(e);
          },
          complete: function complete(e) {
            // silder();
            console.log(7);
          }
        });
      }
    }
  });

  console.log(6);
});