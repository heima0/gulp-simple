
$(function(){
  
  $('#l-map').height(document.body.clientHeight);
  $('#result').height(document.body.clientHeight - 17);
  $('#list').height(document.body.clientHeight - 85);
  // 百度地图API功能
  var map = new BMap.Map("l-map");          // 创建地图实例
  var point = new BMap.Point(116.403694,39.927552);  // 创建点坐标
  map.centerAndZoom(point, 11);                 // 初始化地图，设置中心点坐标和地图级别
  map.enableScrollWheelZoom();
  var top_right_control = new BMap.ScaleControl({anchor: BMAP_ANCHOR_BOTTOM_LEFT});// 右上角，添加比例尺
  map.addControl(top_right_control);
  // 添加3维视图
  var mapType1 = new BMap.MapTypeControl({mapTypes: [BMAP_NORMAL_MAP,BMAP_HYBRID_MAP]});
  var mapType2 = new BMap.MapTypeControl({anchor: BMAP_ANCHOR_TOP_LEFT});

  var overView = new BMap.OverviewMapControl();
  var overViewOpen = new BMap.OverviewMapControl({isOpen:true, anchor: BMAP_ANCHOR_BOTTOM_RIGHT});
  //添加地图类型和缩略图
  function add_control(){
    map.addControl(mapType1);          //2D图，卫星图
    map.addControl(mapType2);          //左上角，默认地图控件
    map.setCurrentCity("北京");        //由于有3D图，需要设置城市哦
    map.addControl(overView);          //添加默认缩略地图控件
    map.addControl(overViewOpen);      //右下角，打开
  }
  add_control();
  //添加默认缩放平移控件
  var top_right_navigation = new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_RIGHT, type: BMAP_NAVIGATION_CONTROL_LARGE});
  map.addControl(top_right_navigation);

  var key1;
  var key;
  var flag = 1;
  var detail = '';
  var dataUrl = '';
  var table_id = '184865';
  $.ajax({
      url:'http://api.map.baidu.com/geosearch/v3/local?ak=GMmCz5DStGZreNL48CQiVP7Bc8e7suYw&page_index='+ 0 +'&page_size=250&geotable_id='+table_id+'&sortby=c_id:1',
        type:'get',
        dataType: 'jsonp',
    })
    .done(function(data) {
          // console.log(data);
          var num = 0;
          var dom = '';
          var markerArr = [];
          for(var i = 0; i < data.contents.length; i++){
                // 动态 创建列表
                var c_n = 0;
                  var c_num = parseInt(data.contents[i].c_level);
                  switch(c_num){
                    case 5: c_n = 'AAAAA'; //★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★★★ ★★★
                    break;
                    case 4: c_n = 'AAAA';
                    break;
                    case 3: c_n = 'AAA';
                    break;
                    case 2: c_n = 'AA';
                    break;
                    case 1: c_n = 'A';
                    break;
                    default: c_n = '非A类景区';
                    break;
                  }
                  dom = '<li id="'+i+'-l" name1="'+data.contents[i].location[0]+'" name2="'+data.contents[i].location[1]+'">'+'<span class="l">'
                      +data.contents[i].title+'</span>'
                      +'<span class="r">'+c_n+'</span></li>'

                  $('ul#list').append(dom);
                  
                  if(data.contents[i].c_feature == '更新中'){
                    detail = '详情更新中';
                    dataUrl = 'javascript:void(0);';
                  }else{
                    detail = '详情»';
                    dataUrl = data.contents[i].c_url;
                  }

                  var content = '<div id="info1" style="margin:0;line-height:22px;font-size:15px;padding:8px;">' +
                  '<font>等级</font>：<font color="#000">'+ c_n +'</font><br/><font>特色</font>：'+ data.contents[i].c_feature +'<br/><font>电话</font>：'+ data.contents[i].c_phone +'<br/><a target="_blank" style="float: right;margin-right: 25px;margin-top: 10px;color: blue;font-weight: 700;font-size: 13px;" href="'
                  + dataUrl +'">'+ detail +'</a>' +
                        '</div>';

                  //创建检索信息窗口对象
                  var searchInfoWindow = null;
                  var new_point = new BMap.Point(data.contents[i].location[0],data.contents[i].location[1]);

                  var myIcon = new BMap.Icon("./images/icon_s.png", new BMap.Size(22,31));

                  var marker = new BMap.Marker(new_point,{icon:myIcon}); //创建marker对象
                  searchInfoWindow = new BMapLib.SearchInfoWindow(map, content, {
                    title  : data.contents[i].title,      //标题
                    width  : 290,             //宽度
                    height : 105,              //高度
                    panel  : "panel",         //检索结果面板
                    enableAutoPan : true,     //自动平移
                    searchTypes   :[
                      // BMAPLIB_TAB_SEARCH,   //周边检索
                      BMAPLIB_TAB_TO_HERE,  //到这里去
                      BMAPLIB_TAB_FROM_HERE //从这里出发
                    ]
                  }); 

                  map.addOverlay(marker); //在地图中添加mark
                  marker.label = new BMap.Label(data.contents[i].title, {offset:new BMap.Size(20,-5)});
                  marker.label.setStyle({  
                      display:"none",  //给label设置样式，任意的CSS都是可以的
                      padding:'2px 5px',
                      border:'1px solid #000',
                      borderRadius: '6px',
                  });
            
                  marker.setLabel(marker.label); //添加百度label
                  marker.info = searchInfoWindow
                  markerArr.push(marker);
                  var ids = "#"+i+"-l";
                  $(ids).click(function(event) {
                        var c_n = 0;
                        var c_num = parseInt(data.contents[parseInt($(this).attr('id'))].c_level);
                        switch(c_num){
                          case 5: c_n = 'AAAAA';
                          break;
                          case 4: c_n = 'AAAA';
                          break;
                          case 3: c_n = 'AAA';
                          break;
                          case 2: c_n = 'AA';
                          break;
                          case 1: c_n = 'A';
                          break;
                          default: c_n = '非A类景区';
                          break;
                        }
                        if(data.contents[parseInt($(this).attr('id'))].c_feature == '更新中'){
                          detail = '详情更新中';
                          dataUrl = 'javascript:void(0);';
                        }else{
                          detail = '详情»';
                          dataUrl = data.contents[parseInt($(this).attr('id'))].c_url;
                        }
                        var content = '<div id="info1" style="margin:0;line-height:22px;font-size:15px;padding:8px;">' +
                        '<font>等级</font>：<font color="#000">'+ c_n +'</font><br/><font>特色</font>：'+ data.contents[parseInt($(this).attr('id'))].c_feature +'<br/><font>电话</font>：'+ data.contents[parseInt($(this).attr('id'))].c_phone +'<br/><a target="_blank" style="float: right;margin-right: 25px;margin-top: 10px;color: blue;font-weight: 700;font-size: 13px;" href="'
                        + dataUrl +'">'+ detail +'</a>' +
                              '</div>';
                        //创建检索信息窗口对象
                        var searchInfoWindow = null;
                        var new_point = new BMap.Point($(this).attr('name1'),$(this).attr('name2'));

                        var myIcon = new BMap.Icon("./statics/images/map/icon_s.png", new BMap.Size(22,31));

                        var marker = new BMap.Marker(new_point,{icon:myIcon}); //创建marker对象

                        searchInfoWindow = new BMapLib.SearchInfoWindow(map, content, {
                          title  : data.contents[parseInt($(this).attr('id'))].title,      //标题
                          width  : 290,             //宽度
                          height : 105,              //高度
                          panel  : "panel",         //检索结果面板
                          enableAutoPan : true,     //自动平移
                          searchTypes   :[
                            BMAPLIB_TAB_TO_HERE,  //到这里去
                            BMAPLIB_TAB_FROM_HERE //从这里出发
                          ]
                        }); 

                        searchInfoWindow.open(marker);
                        $('.BMapLib_SearchInfoWindow').css({
                          'opacity': '1',
                          'border': '0 none',
                          'borderRadius': '10px',
                          'marginTop': '10px',
                        });

                        $('.BMapLib_bubble_title').css('fontWeight', '800');
                    
                        $('#info1').parent().css('background', '');


                        if($('.BMapLib_bubble_title').offset().left < 260){

                          if($('.BMapLib_bubble_title').offset().left+parseInt($('.BMap_mask').siblings().css('left')) < 260){

                            $('.BMap_mask').siblings().css('left', '250px');

                          }

                        }else{
                          $('.BMap_mask').siblings().css('left', '0px');

                          if($('.BMapLib_bubble_title').offset().left+parseInt($('.BMap_mask').siblings().css('left')) < 260){

                            $('.BMap_mask').siblings().css('left', '250px');

                          }else{
                            $('.BMap_mask').siblings().css('left', '0px');

                          }

                        }
                  });
                














                

          }
          for(var i = 0; i < markerArr.length; i++){
            markerArr[i].addEventListener("click", function(e){
                this.info.open(this);
                $('.BMapLib_SearchInfoWindow').css({
                  'opacity': '1',
                  'border': '0 none',
                  'borderRadius': '10px',
                  'marginTop': '10px',
                });
                $('.BMapLib_bubble_title').css('fontWeight', '800');
              $('#info1').parent().css('background', '');

              })
            
            markerArr[i].addEventListener("mouseover", function(){  
                this.label.setStyle({    //给label设置样式，任意的CSS都是可以的
                    display:"block"
                });
            }); 
             
            markerArr[i].addEventListener("mouseout", function(){ 
                this.label.setStyle({    //给label设置样式，任意的CSS都是可以的
                    display:"none"
                }); 
            });
          }

          $('#pnl_phone_left table').css('fontSize','14px');

  })
  .complete(function(data){
    // 当前高亮
    $('#list li').each(function(i, e) {
      $(e).click(function(event) {
        // 排他
        $('#list li').each(function(i,e){
          $(e).css({'background': '#fff','font-weight':'400'});
        });

        $(this).css({'background': '#f6f6f6','font-weight':'700'});
      });
    });
  })

  $('#l-map').click(function(event) {
    $('#list li').css({'background': '#fff','font-weight':'400'});
  });

  // 隐藏 显示 侧边栏  
  var hid = document.querySelector('#hid');
  $('#hid').css('background', 'url(./images/l.png) center no-repeat');
  hid.onclick = function(){
    // $('.BMapLib_SearchInfoWindow').css('display', 'none');
    $('.BMap_pop').css('display', 'none');
    //►◄
    if($(this).hasClass('in1')){
      // alert(2);
      $(this).toggleClass('in1');
      // alert($(this).hasClass('in1'));
      $('.BMap_mask').siblings().css('left', '0px');
      $(this).animate({marginLeft:'2px'}, 300).parent().animate({'width': 0}, 100);
      $('#result').css('border','0 none');
      $('#l-map').animate({marginLeft:'0px'}, 500);
      if(flag == 1){
        flag++;
        $('div span img').addClass('jd');
      }
      $('#hid').css('background', 'url(./images/r.png) center no-repeat');

    }else{
      // alert(3);
      $(this).toggleClass('in1');
      // alert($(this).hasClass('in1'));
      setTimeout(function(){$('div .BMap_shadow img').css('display', 'none');}, 0)
      $('#result').css('border','1px solid #ccc');
      $(this).animate({marginLeft:'360px'}, 300).text(' ').parent().animate({'width': 355}, 100);
      // $('#l-map').animate({marginLeft:'266px'}, 500);
      // $('.search input').val('');
      // submit();
      // setTimeout(function(){$('div span img.jd').css('display', 'block');}, 100)
      // hid.style.transform = 'rotate(360deg)';
      $('#hid').css('background', 'url(./images/l.png) center no-repeat');
      
    }
  }

  // 封装 将任意对象 ，缓动移动到 某位置
  function animate(obj, target) {
      clearInterval(obj.timer);
      obj.timer = setInterval(play, 15);
      function play() {
          var leader = obj.offsetLeft;
          var step=(target-leader)/10;
          step=step>0?Math.ceil(step):Math.floor(step);
          leader+=step;
          if (Math.abs(leader - target) > step) {
              obj.style.left = leader + "px";
          } else {
              obj.style.left = target + "px";
              clearInterval(obj.timer);
          }
      }
  }
  
  document.onkeydown=function(event){
    var event=window.event||event;  
        if(event.keyCode == 13){

      submit();
            
        }
    }

  $('.BMap_mask').click(function(event) {
    $('.BMapLib_SearchInfoWindow').css('display', 'none');
  });
  

})  