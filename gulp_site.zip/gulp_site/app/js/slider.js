$(function(){

      var mvisual = {
          parentElement:$("#mainVisual"),
          parentControl:$("#mainVisual .parentControl button"),
          parentGround:$("#mainVisual .obj"),
          parentItem:$("#mainVisual .item"),
          childControl:$("#mainVisual .control button"),
          childGround:$("#mainVisual .child"),
          childWrapNode:".objChildren",
          childCtrlNode:".control",
          childPageNode:".control span",
          childItemNode:".childItem",
          parentIndex:0,
          childIndex:0
        }

      var setMovement,setTime=5000;
      var parentIndex = mvisual.parentIndex;
      var childIndex = mvisual.childIndex;

      mvisual.parentItem.css({opacity:0});

      var scene1 = function(){

         var inWidth = (parseInt(mvisual.parentItem.eq(parentIndex).find(mvisual.childCtrlNode).children().children().size())*20)/2;
         var outWidth = (parseInt(460)/2);
         var divWidth = outWidth - inWidth;

        mvisual.parentItem.eq(parentIndex)
          .stop(true,false).show()
            .animate({opacity:1},1000,'easeInOutCubic')

          .find(mvisual.childWrapNode)
            .css({top:20,opacity:0})
              .stop(true,false).delay(300)
                .animate({top:0,opacity:1},800,'easeInOutCubic')

          .find(mvisual.childCtrlNode)
            .css({marginLeft:divWidth,opacity:0})
              .stop(true,false).delay(700)
                //.animate({marginLeft:0,opacity:1},1300,'easeInOutCubic')
                .animate({marginLeft:divWidth,opacity:1},1200,'easeInOutCubic')

          .parent().find(mvisual.childItemNode)
            .css({top:-20,opacity:0})
              .stop(true,false).delay(700)
                .animate({top:0,opacity:1},800,'easeInOutCubic');
      }

      var scene2 = function(){
        mvisual.parentItem.not(parentIndex)
          .stop(true,false)
            .animate({opacity:0},1000,'easeInOutCubic',function(){
              $(this).hide();
            })

          .find(mvisual.childWrapNode)
            .stop(true,false)
              .animate({opacity:0},800,'easeInOutCubic');
      }

      //------------

      var pageContext = [];

      $("#mainVisual .item").each(function(index){
        if(index === 0){
          pageContext[index] = '<button type="button" class="ov go-button go-ir">'+(index+1)+'</button>';
        }else{
          pageContext[index] = '<button type="button" class="go-button go-ir">'+(index+1)+'</button>';
        }
      });


      mvisual.parentItem.find(mvisual.childPageNode).html(pageContext.join(''));


      mvisual.parentItem.not(mvisual.parentItem.eq(parentIndex)).css({opacity:0})
        .not(mvisual.parentItem.eq(parentIndex).find(mvisual.childItemNode).eq(childIndex)).css({opacity:0});

      scene1();

      mvisual.parentElement.find(".l,.r").css({opacity:0.3});

      //------------
      function setParentMovement(){
        switch(arguments[0]){
          case "prev" :
            if(parentIndex > 0){
              parentIndex--;
            }else{
              parentIndex = mvisual.parentItem.size()-1;
            }
          break;
          case "next" :
            if(parentIndex < mvisual.parentItem.size()-1){
              parentIndex++;
            }else{
              parentIndex = 0;
            }
          break;
          default:
            parentIndex = arguments[0];
          break;
        }
        mvisual.parentItem.find(mvisual.childPageNode).children().removeClass("ov")
          .parent().eq(parentIndex).children().eq(parentIndex).addClass("ov");

        $(document).queue(scene2).dequeue().queue(scene1).dequeue();
        if(arguments[0] != "prev" && arguments[0] != "next") {
          mvisual.parentItem.find(mvisual.childPageNode).eq(parentIndex).children().eq(parentIndex).focus();
        }
      }

      function parentController(e){
        setParentMovement(e.attr("data-type"));
        mvisual.parentElement.find("[data-type='stop']").hide();
        mvisual.parentElement.find("[data-type='play']").show();
      }

      function childController(e){


        if(e.attr("data-type") === undefined){
          
          if(e.parent().find(".ov").index() !== e.index()){
            // mvisual.parentElement.find("[data-type='stop']").hide();
            // mvisual.parentElement.find("[data-type='play']").show();
            setParentMovement(e.index());
          }

        }else{

          if(e.attr("data-type") == "play"){
            autoPlay();
            mvisual.parentElement.find("[data-type='play']").hide();
            mvisual.parentElement.find("[data-type='stop']").show().focus();
          }

          if(e.attr("data-type") == "stop"){

            mvisual.parentElement.find("[data-type='stop']").hide();
            mvisual.parentElement.find("[data-type='play']").show().focus();
          }

        }
      }

      function autoPlay(){
        setMovement = setInterval(function(){
          setParentMovement("next");
        },setTime);
      }

      //------------
      $(mvisual.parentControl).click(function(event) {
        parentController($(this))
      });
      $('#mainVisual .control button').click(function(event) {
        childController($(this))
      });
      $(mvisual.childControl).hover(function(event) {
        clearInterval(setMovement);
      });

      $(mvisual.parentControl).mouseenter(function(){
        clearInterval(setMovement);
      })
      $(mvisual.parentControl).mouseleave(function(){
        autoPlay()
      })
      $('#mainVisual .control button').mouseenter(function(){
        clearInterval(setMovement);
      })
      $('#mainVisual .control button').mouseleave(function(){
        autoPlay()
      })

      autoPlay();


    (function(){
      // 오버

      $(".panel a").hover(
        function(){
          $(this).addClass("active");

          $(this).find(".over")
            .css({'opacity':'0'}).stop(true,false)
            .animate({'opacity':'1'},300,"easeOutCubic");
        },
        function(){
          $(this).removeClass("active");

          $(this).find(".over").stop(true,false)
            .animate({'opacity':'0'},300,"easeOutCubic");
        }
      );
    }());
})

$(function(){
  
  var arrSlider = [];
  $('#wrap .item>a>img').each(function(index, el) {
    arrSlider[arrSlider.length] = $(el).attr('src')
  });

  $('#wrap .item').each(function(index, el) {
    var flg1 = index -1;
    var flg2 = index +1;
    if(flg1 == -1){
      flg1 = 4;
    }
    if(flg2 == 5){
      flg2 = 0;
    }
    $(this).find('.r img').attr('src', arrSlider[flg1]);
    $(this).find('.l img').attr('src', arrSlider[flg2]);
  });

})

