
$(function(){

// 切换语言
function state(id)
{
  // console.log(111)
  var obj = document.getElementById(id);
  // console.log(obj)
  // console.log(id)

  if(!obj)
  {
    return;
  }
  var oUl = obj.getElementsByTagName("ul")[0];
  var t = null;
  
  oUl.onmouseover=obj.onmouseover=function ()
  {
    $('span.English').css('background', 'url(http://r1.visitbeijing.com.cn/images/b53ac031bf2cc8f1eb6d4291faa661f9.png) no-repeat right 2px')
    clearTimeout(t);
    t = null;
    oUl.style.display = "block";
  };
  
  obj.onmouseout=function ()
  {
    t = setTimeout(function ()
    {
      $('span.English').css('background', 'url(http://r1.visitbeijing.com.cn/images/a35682a78ee4660e500b67e3dd4d75bd.jpg) no-repeat right -2px')
      oUl.style.display = "none";
    },300);
  };
}
state('state');

  // 导航
  jQuery("#nav").slide({ type:"menu", titCell:".nLi", targetCell:".sub",effect:"slideDown",delayTime:300,triggerTime:0,returnDefault:true});

  //  键盘事件(搜索)
  var $searchBtn = $(".search button");
  var $searchInput = $(".search #q");
  var input = document.getElementById("q");
  $searchBtn.on("click", function() {
      var key = $searchInput.val();
      // console.log(13);
      window.open('http://www.visitbeijing.com.cn/f/search.html?key=' + key);
  });
  document.onkeydown=function(event){
      if(event.keyCode == 13){
              var hasFocus = document.hasFocus() && document.activeElement === input;
              if(hasFocus){
                  $searchBtn.click();
                  // console.log(hasFocus);
              } else{
                  // console.log(hasFocus);
              }
      }
  }







  







































})





















