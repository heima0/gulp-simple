
// 基于superslider.js的组件
function nav(){
  // 顶部导航
  $(".nav").slide({ type:"menu", titCell:".nLi", targetCell:".sub",effect:"slideDown",delayTime:300,triggerTime:0,returnDefault:true});

  //右侧导航
  var btb=$(".rightNav");
  var tempS;
  $(".rightNav").hover(function(){
      $(this).css('z-index',300);
      var thisObj = $(this);
      tempS = setTimeout(function(){
      thisObj.find("a").each(function(i){
        var tA=$(this);
        setTimeout(function(){ tA.animate({right:"0"},200);},50*i);
      });
    },200);
  },function(){
      $(this).css('z-index',100);
    if(tempS){ clearTimeout(tempS); }
    $(this).find("a").each(function(i){
      var tA=$(this);
      setTimeout(function(){ tA.animate({right:"-110"},200,function(){
      });},50*i);
    });
  });
  var vn = $("#viewNew");
  vn.click(function(){
    if ( vn.hasClass("new") ){ $(".demoList li:not('.new')").hide(); vn.removeClass("new").html("<em>all</em>显示全部") }
    else{ $(".demoList li").show(); vn.addClass("new").html("<em>new</em>只显示New") }

  });
  $(".newOnly").click(function(){
    $(".demoList li:not('.new')").hide()
  });
  $(".showAll").click(function(){
    $(".demoList li").show()
  });
  var hig = $('.rightNav').offset().top;
  var hig1 = $('.content').offset().top;
  $('.rightNav').css({
    position: 'absolute',
    top: hig1
  });
  $(window).scroll(function(){
      // console.log($('.rightNav').offset().top - $(window).scrollTop())
      if($('.rightNav').offset().top - $(window).scrollTop() <= 150){
        $('.rightNav').css({
          position: 'fixed',
          top: 150
        });
      }
      if(hig - $(window).scrollTop() >= 150){
        $('.rightNav').css({
          position: 'absolute',
          top: hig1
        });
      }
  });

  // cat切换
  jQuery(".foucebox").slide({ mainCell:".bd ul", effect:"fold", autoPlay:true, delayTime:1000, triggerTime:50, startFun:function(i){   
    //下面代码控制鼠标状态滑动    
    jQuery(".foucebox .hoverBg").animate({"margin-top":60*i},250);  
  }});    



}