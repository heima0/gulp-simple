$(function(){
new Vue({
    el: '#site',
    data: function () {
      return {
        articles: {
          author: ''
        }
      }
    },
    created(){
      var _this = this;
      $.ajax({
        url: 'https://cnodejs.org/api/v1/topic/' + this.getId('id'),
        type: 'get',
        success: function success(data) {
          _this.articles = data.data;
        },
        error: function error(e) {
          console.log(e);
        },
        complete: function complete(e) {
          // silder();
          console.log('finish');
        }
      });
    },
    mounted(){
    },
    updated(){

    },
    methods: {
      getId(name){
         var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
         var r = window.location.search.substr(1).match(reg);
         if(r!=null)
         return unescape(r[2]);
         return null;
      }
    }
})
})




