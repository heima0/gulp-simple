

var gulp = require("gulp");//引入本地安装的 gulp模块

var fileinclude = require('gulp-file-include');//组件化HTML

var sass = require('gulp-sass'); // 引入sass组件

var browserSync = require('browser-sync'); // 自动刷新服务

var useref = require('gulp-useref');  // 合并js、css文件
  
var uglify = require('gulp-uglify');  // 压缩js文件

var watch = require("gulp-watch"); // 监听

var gulpIf = require('gulp-if');  // gulp-if来做不同处理。

var minifyCSS = require('gulp-minify-css'); // 压缩css文件

var del = require('del'); // 清除

var babel = require("gulp-babel"); // es6-es5

var imagemin = require('gulp-imagemin'); // 压缩图片

// 组件化
gulp.task('fileinclude', function() {
    gulp.src(['./app/template/*.html'])
        .pipe(fileinclude({
          prefix: '@@',
          basepath: './app/template/include/'
        }))
        .pipe(gulp.dest('./app/'))
});

// es6-es5
gulp.task("es6", function () {
  return gulp.src('app/js/index.js')
    .pipe(babel()) 
    .pipe(gulp.dest('app/js/'))
    .pipe(browserSync.reload({
      stream: true
  }))
});

// 清理dist目录
gulp.task('clean', function(){
  return del('dist');
})

// 压缩图片
gulp.task('images', function(){
  return gulp.src('app/images/**/*.+(png|jpg|gif|svg|ico)')
  .pipe(imagemin())
  .pipe(gulp.dest('dist/images'))
});

// 服务
gulp.task('browserSync', function(){
  browserSync({
    server:{
      baseDir: 'app'
    },
  })
});

// 压缩合并css/js
gulp.task('useref', function(){
  return gulp.src('app/*.html')
    .pipe(gulpIf('*.css', minifyCSS()))
    .pipe(gulpIf('*.js', uglify()))
    .pipe(useref())
    .pipe(gulp.dest('dist'))
});

// css 预处理
gulp.task('sass', function(){
  return gulp.src('app/scss/*.scss')
  .pipe(sass())
  .pipe(gulp.dest('app/css/'))
  .pipe(browserSync.reload({
    stream: true
  }))
  console.log("Hello World");
});

// 开启监听，执行sass,fileinclude。
gulp.task('watch',[ 'browserSync','fileinclude', 'sass'], function(){
  gulp.watch('app/scss/**/*.scss', ['sass']);   // 预处理
  gulp.watch('app/template/**/*.html', ['fileinclude']);  // 组件化
  gulp.watch('app/**/*.html', browserSync.reload); // html改变刷新
  gulp.watch('app/js/**/*.js', browserSync.reload); // js改变刷新
  gulp.watch('app/css/**/*.css', browserSync.reload);  //css改变刷新
});

// 打包
gulp.task('build', ['clean', 'es6', 'sass', 'images', 'useref'], function(){
  return gulp.src("src/**/*.js")// ES6 源码存放的路径
    .pipe(babel()) 
    .pipe(gulp.dest("dist"));
});




