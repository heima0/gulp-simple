

var gulp = require("gulp");//引入本地安装的 gulp模块

var sass = require('gulp-sass'); // 引入sass组件

var browserSync = require('browser-sync'); // 自动刷新服务

var useref = require('gulp-useref');  // 合并js、css文件
  
var uglify = require('gulp-uglify');  // 压缩js文件

var babel = require('gulp-babel');

var babel = require('babel-core');

var gulpIf = require('gulp-if');
var minifyCSS = require('gulp-minify-css'); // 压缩css文件

var del = require('del');

gulp.task('clean', function(){
  del('dist');
})



gulp.task('browserSync', function(){
  browserSync({
    server:{
      baseDir: 'app'
    },
  })
})


gulp.task('useref', function(){
  return gulp.src('app/*.html')
  .pipe(useref())
  .pipe(gulpIf('*.css', minifyCSS()))
  .pipe(gulpIf('*.js', uglify()))
  .pipe(gulp.dest('dist'));
})


gulp.task('sass', function(){
  return gulp.src('app/scss/*.scss')
  .pipe(sass())
  .pipe(gulp.dest('app/css/'))
  .pipe(browserSync.reload({
    stream: true
  }))
  console.log("Hello World");
})

gulp.task('watch',['browserSync', 'sass'], function(){
  gulp.watch('app/scss/**/*.scss', ['sass']);
  gulp.watch('app/**/*.html', browserSync.reload);
  gulp.watch('app/js/**/*.js', browserSync.reload);
  gulp.watch('app/css/**/*.css', browserSync.reload);
})



gulp.task('build', ['clean', 'sass', 'useref'], function(){
  console.log('hello');
})







