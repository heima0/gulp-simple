
$(function(){

  var arrSlide = [];
  $('.slider .tempWrap li').each(function(i,v){
    arrSlide[arrSlide.length] = $(this).find('p').text();
  })
  $('.slider .hd p').text(arrSlide[0]);

  jQuery(".slider .bd li").first().before( jQuery(".slider .bd li").last() );       
  jQuery(".slider").hover(function(){ jQuery(this).find(".arrow").stop(true,true).fadeIn(300) },function(){ jQuery(this).find(".arrow").fadeOut(300) });        
  jQuery(".slider").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"leftLoop",  autoPlay:true, vis:3, autoPage:true, trigger:"click",endFun:function(){
    $('.slider .hd p').text(arrSlide[$('.slider .hd li.on').index()]);
  }}); 




  // 汇率-天气
  // 获取天气

  $.ajax({
      url: 'http://api-hq.visitbeijing.com.cn/widget/weather',
      dataType: 'jsonp'
  })
  .done(function(data) {
      // console.log(data);
      getWeather(data);
  })
  .fail(function() {
      console.log("error");
  })
  .always(function() {
      // console.log("complete");
  });

  //数据请求成功回调函数，用于将获取到的数据放入页面相应位置
  function getWeather(response) {
      var oSpan = document.getElementsByClassName('infos');
      var data = response.data.results;
      var weeks = data.week;
      oSpan[0].innerHTML = 'Beijing';

      var arrDate = data.days.split('-')
      arrDate.shift()
      oSpan[1].innerHTML = arrDate.reverse().join('/');
      
      var arr = data.temperature.split('/');

      var arr1 = [];
      // 将 °F 和°C之间 换算        公式：  °F =  32 + °C × 1.8  
      for(var i = 0; i<arr.length; i++){
          arr1[arr1.length] = Math.round((32 + parseFloat(arr[i]) * 1.8)*100)/100 + '°F';
      }

      chooseDate(weeks);

      oSpan[2].innerHTML = arr1.join(' ~ ');

      var aDiv = document.getElementsByClassName('future_box');
    
      //根据返回数据，替换不同天气图片
      changeImg(data);
      
  }

  //根据获取到的数据更改页面中相应的图片
  function changeImg(data) {
      var today_container = document.getElementById('today_container');
      var firstImg = today_container.getElementsByTagName("img")[0];
      var firstWeatherId = data.weatid;
      // console.log(firstWeatherId)
      chooseImg(firstWeatherId, firstImg);   
  }

  //星期转化
  function chooseDate(weeks) {
      var oSpan = document.getElementsByClassName('infos');
      switch (weeks) {
          case '星期一':
              oSpan[2].innerHTML = 'Mon';
              break;
          case '星期二':
              oSpan[2].innerHTML = 'Tues';
              break;
          case '星期三':
              oSpan[2].innerHTML = 'Wed';
              break;
          case '星期四':
              oSpan[2].innerHTML = 'Thur';
              break;
          case '星期五':
              oSpan[2].innerHTML = 'Fri';
              break;
          case '星期六':
              oSpan[2].innerHTML = 'Sat';
              break;
          case '星期日':
              oSpan[2].innerHTML = 'Sun';
              break;
          default:
              oSpan[2].innerHTML = '';
      }
  }

  //选择图片
  function chooseImg(id, index) {
      switch (id) {
          case '1':
              index.src = 'https://t1.huanqiu.cn/445a12f864a5d3e5b0734b87e35a3fe1.png';
              break;
          case '2':
              index.src = 'https://t1.huanqiu.cn/0150c02f7711a384b5cb495f56671995.png';
              break;
          case '3':
              index.src = 'https://t1.huanqiu.cn/9d70eef9d6506769654bc430ae83366b.png';
              break;
          case '4':
          case '5':
          case '6':
          case '8':
          case '9':
          case '10':
          case '11':
          case '12':
          case '13':
          case '20':
          case '22':
          case '23':
          case '24':
          case '25':
          case '26':
              index.src = 'https://t1.huanqiu.cn/5e09c79bc28f6c412983b990aeb7a124.png';
              break;
          case '7':
              index.src = 'https://t1.huanqiu.cn/ab0dcabd6c637f03a8d4142ef0678979.png';
              break;
          case '14':
          case '15':
          case '16':
          case '17':
          case '18':
          case '27':
          case '28':
          case '29':
              index.src = 'https://t1.huanqiu.cn/31af8ebfa121ed81cac656e043afd0b1.png';
              break;
          case '19':
          case '21':
          case '30':
          case '31':
          case '32':
          case '33':
              index.src = 'https://t1.huanqiu.cn/ce25dfb368a57c5cefda59b60f37014d.png';
              break;
          default:
              index.src = 'https://t1.huanqiu.cn/d3849346c3e9d9f5ae14132c8017bdae.png';
      }
  }


  // 汇率
  $.ajax({
    url: 'http://api-hq.visitbeijing.com.cn/widget/exchangerate?from=fixerio',
    dataType: 'jsonp'
  })
  .done(function(data) {
    rates(data.data.results.rates);
  })
  .fail(function() {
    console.log("error");
  })
  .always(function() {
    // console.log("complete");
  });

  function rates(data){
    var usd = Math.round(data.USD*100*100)/100;
    var gbp = Math.round(data.GBP*100*100)/100;
    var eur = Math.round(data.EUR*100*100)/100;
    var aud = Math.round(data.AUD*100*100)/100;
    $('.rate1').text(usd);
    $('.rate2').text(gbp);
    $('.rate3').text(eur);
    $('.rate4').text(aud);
  }






})




























